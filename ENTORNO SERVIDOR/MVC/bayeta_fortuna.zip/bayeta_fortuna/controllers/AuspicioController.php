<?php

    class AuspicioController{

        public function index() {

        require __DIR__ . '/../views/index.php';

        }




    }


?>